#Post-process Band Structure
# Use vaspkit -task 211 to get some files like BAND_GAP, KLABELS, BAND.dat, FERMI_ENERGY ... (pure functional)
# Use vaspkit -task 252 to get some files like BAND_GAP, KLABELS, BAND.dat, FERMI_ENERGY ... (hybrid functional) 

# necessary files: BAND_GAP, KLABELS, BAND.dat
# alidost.sumeyye@yahoo.com

import matplotlib.pyplot as plt

# Reading gap value
G= open("BAND_GAP", "r").readlines()
Gap = float(G[2].split()[3])


Fermi = 0 # Real Fermi value shifted to 0 in BAND.dat file

#Parsing KLABELS file
KL=open("KLABELS", "r").readlines()[1:]


L = []
for line in KL:
    L.append(line)
    if len(line.strip()) == 0 :
        break

KPOINTS= []
KPOINTS_COORD= []
for l in range(len(L)-1):
    KPOINTS.append(L[l].split()[0])
    KPOINTS_COORD.append(float(L[l].split()[1]))


#KPOINTS= [r'$\Gamma$',r'$X|Y$',r'$\Gamma$' , r'$Z|R$',r'$\Gamma$', r'$T|U$',r'$\Gamma$',    r'$V$']


#Parsing Band.date file
B= open("BAND.dat", "r").readlines()

NKPTS=B[1].split()[4]
NBANDS=B[1].split()[5]
KPTS_CBM = []
KPTS_VBM = []
BANDS_CBM = []
BANDS_VBM = []

for j in range(int(NBANDS)):
    for i in range(int(NKPTS)):
        if Gap != 0: # To find out if the system is metallic or not
            if float(B[i+3+(int(NKPTS)+2)*j].split()[1]) > float(Fermi):
                KPTS_CBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[0]))
                BANDS_CBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[1]))
            else:
                KPTS_VBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[0]))
                BANDS_VBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[1]))
        else:
            KPTS_VBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[0]))
            BANDS_VBM.append(float(B[i+3+(int(NKPTS)+2)*j].split()[1]))


# Finding band edges to see if the gap is direct or indirect
if Gap != 0:
    print("\nSystem is not metalic\n")
    CBM_BAND_edge = min(BANDS_CBM)
    CBM_KPT_edge = KPTS_CBM[BANDS_CBM.index(min(BANDS_CBM))]
    print("CBM=",CBM_KPT_edge,CBM_BAND_edge)
    VBM_BAND_edge = max(BANDS_VBM)
    VBM_KPT_edge = KPTS_VBM[BANDS_VBM.index(max(BANDS_VBM))]
    print("VBM=",VBM_KPT_edge,VBM_BAND_edge)
    plt.plot(KPTS_CBM, BANDS_CBM,"-",linewidth=2.2,color="orange",zorder=1)
    plt.plot(KPTS_VBM, BANDS_VBM,"-",linewidth=2.2,color='#1f77b4',zorder=1)
    plt.scatter(CBM_KPT_edge,CBM_BAND_edge,color="#32CD32",s=150,zorder=2)
    plt.scatter(VBM_KPT_edge,VBM_BAND_edge,color='#FF4500',s=150,zorder=2)
    if CBM_KPT_edge != VBM_KPT_edge:
        print("Indirect Gap = ", Gap)
    else:
        print("Direct Gap =", Gap)
else:
    print("System is metalic\n")
    plt.plot(KPTS_CBM, BANDS_CBM,"-",linewidth=2.2,color="orange",zorder=1)
    plt.plot(KPTS_VBM, BANDS_VBM,"-",linewidth=2.2,color="orange",zorder=1)


plt.xticks(KPOINTS_COORD, KPOINTS,size="13")
plt.yticks(size="15")



plt.ylim([-5,7])
plt.xlim([min(KPTS_VBM),max(KPTS_VBM)]) # or [min(KPTS_CBM),max(KPTS_CBM)]
plt.xlim([0,4.042])
plt.title("Vaspkit band structure")
plt.grid()
plt.show()

